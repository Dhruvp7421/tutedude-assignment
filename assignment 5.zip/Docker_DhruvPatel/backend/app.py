from flask import Flask, request, jsonify

app = Flask(__name__)


@app.route("/")
def health():
    return jsonify(status="ok", service="flask-backend")


@app.route("/submit", methods=["POST"])
def submit():
    data = request.get_json(silent=True) or request.form.to_dict()
    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    message = (data.get("message") or "").strip()

    if not name or not email or not message:
        return jsonify(success=False, error="All fields are required."), 400

    # Process the data (simple example processing)
    result = {
        "success": True,
        "name": name.title(),
        "email": email.lower(),
        "message": message,
        "message_length": len(message),
        "word_count": len(message.split()),
    }
    return jsonify(result), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
