const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
// In Docker Compose the backend is reachable by its service name
const BACKEND_URL = process.env.BACKEND_URL || "http://backend:5000";

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "views", "index.html"));
});

app.post("/submit", async (req, res) => {
  try {
    const response = await fetch(`${BACKEND_URL}/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(req.body),
    });
    const data = await response.json();
    res.status(response.status).json(data);
  } catch (err) {
    res.status(502).json({ success: false, error: "Cannot reach backend: " + err.message });
  }
});

app.listen(PORT, "0.0.0.0", () => console.log(`Frontend running on port ${PORT}`));
