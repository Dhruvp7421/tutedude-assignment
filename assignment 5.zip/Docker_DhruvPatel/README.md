# Docker Assignment – Express Frontend + Flask Backend

Run: `docker compose up --build` then open http://localhost:3000

Structure: `frontend/` (Express, port 3000) and `backend/` (Flask, port 5000), joined by `app-network`.
