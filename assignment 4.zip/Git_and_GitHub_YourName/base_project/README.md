# Flask & MongoDB - DevOps Assignment

A Flask app with a JSON API route and a form that stores data in MongoDB Atlas.

## Routes

| Route | Method | Description |
|---|---|---|
| `/api` | GET | Reads `data.json` and returns the list as JSON |
| `/` | GET | Shows the form |
| `/submit` | POST | Inserts the form data into MongoDB Atlas. Success redirects to `/success`; errors are shown on the same page |
| `/success` | GET | Shows "Data submitted successfully" |

## Setup

```bash
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # then edit .env and add your Atlas URI
python app.py
```

Open http://127.0.0.1:5000/ for the form and http://127.0.0.1:5000/api for the JSON.

In MongoDB Atlas, remember to (1) create a database user and (2) add your IP address under
Network Access, otherwise the connection will fail and the form will show the error.

GitHub repository: <paste your link here>
