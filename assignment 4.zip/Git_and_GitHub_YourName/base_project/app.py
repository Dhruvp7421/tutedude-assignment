"""Flask application with:
  Task 1 - /api route that reads a JSON list from data.json and returns it.
  Task 2 - a form that inserts data into MongoDB Atlas, with success redirect
           and same-page error display.
"""
import json
import os
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, redirect, render_template, request, url_for
from pymongo import MongoClient
from pymongo.errors import PyMongoError

load_dotenv()  # reads MONGO_URI etc. from a local .env file (never commit it)

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data.json"

app = Flask(__name__)
app.json.sort_keys = False  # keep the key order used in data.json

_client = None


def get_collection():
    """Return the MongoDB Atlas collection, creating the client on first use."""
    global _client
    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise RuntimeError("MONGO_URI is not set. Add your MongoDB Atlas connection string to the .env file.")
    if _client is None:
        _client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    db = _client[os.environ.get("MONGO_DB", "flask_assignment")]
    return db[os.environ.get("MONGO_COLLECTION", "submissions")]


# ---------------------------------------------------------------- Task 1
@app.route("/api")
def api():
    """Read the list stored in data.json and return it as JSON."""
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return jsonify({"error": "data.json not found"}), 500
    except json.JSONDecodeError:
        return jsonify({"error": "data.json contains invalid JSON"}), 500
    return jsonify(data)


# ---------------------------------------------------------------- Task 2
@app.route("/", methods=["GET"])
def index():
    return render_template("form.html", error=None, form={})


@app.route("/submit", methods=["POST"])
def submit():
    form = {
        "name": request.form.get("name", "").strip(),
        "email": request.form.get("email", "").strip(),
        "message": request.form.get("message", "").strip(),
    }

    # Validation errors stay on the same page (no redirect).
    if not form["name"] or not form["email"] or not form["message"]:
        return render_template("form.html", error="All fields are required.", form=form), 400
    if "@" not in form["email"]:
        return render_template("form.html", error="Please enter a valid email address.", form=form), 400

    try:
        get_collection().insert_one(form.copy())
    except (PyMongoError, RuntimeError) as exc:
        # Database error: show it on the same page, do not redirect.
        return render_template("form.html", error=f"Could not save data: {exc}", form=form), 500

    # Success: redirect to another page.
    return redirect(url_for("success"))


@app.route("/success")
def success():
    return render_template("success.html", message="Data submitted successfully")


if __name__ == "__main__":
    app.run(debug=True)
