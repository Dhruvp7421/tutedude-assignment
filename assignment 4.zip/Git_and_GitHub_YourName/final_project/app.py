"""Flask application with:
  Task 1 - /api route that reads a JSON list from data.json and returns it.
  Task 2 - a form that inserts data into MongoDB Atlas, with success redirect
           and same-page error display.
"""
import json
import os
from pathlib import Path

from dotenv import load_dotenv
from flask import Flask, jsonify, redirect, render_template, request, url_for
from pymongo import MongoClient
from pymongo.errors import PyMongoError

load_dotenv()  # reads MONGO_URI etc. from a local .env file (never commit it)

BASE_DIR = Path(__file__).resolve().parent
DATA_FILE = BASE_DIR / "data.json"

app = Flask(__name__)
app.json.sort_keys = False  # keep the key order used in data.json

_client = None


def get_collection():
    """Return the MongoDB Atlas collection, creating the client on first use."""
    global _client
    uri = os.environ.get("MONGO_URI")
    if not uri:
        raise RuntimeError("MONGO_URI is not set. Add your MongoDB Atlas connection string to the .env file.")
    if _client is None:
        _client = MongoClient(uri, serverSelectionTimeoutMS=5000)
    db = _client[os.environ.get("MONGO_DB", "flask_assignment")]
    return db[os.environ.get("MONGO_COLLECTION", "submissions")]


# ---------------------------------------------------------------- Task 1
@app.route("/api")
def api():
    """Read the list stored in data.json and return it as JSON."""
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        return jsonify({"error": "data.json not found"}), 500
    except json.JSONDecodeError:
        return jsonify({"error": "data.json contains invalid JSON"}), 500
    return jsonify(data)


# ---------------------------------------------------------------- Task 2
@app.route("/", methods=["GET"])
def index():
    return render_template("form.html", error=None, form={})


@app.route("/todo", methods=["GET"])
def todo_page():
    """Frontend To-Do page (form posts to /submittodoitem)."""
    return render_template("todo.html")


@app.route("/submit", methods=["POST"])
def submit():
    form = {
        "name": request.form.get("name", "").strip(),
        "email": request.form.get("email", "").strip(),
        "message": request.form.get("message", "").strip(),
    }

    # Validation errors stay on the same page (no redirect).
    if not form["name"] or not form["email"] or not form["message"]:
        return render_template("form.html", error="All fields are required.", form=form), 400
    if "@" not in form["email"]:
        return render_template("form.html", error="Please enter a valid email address.", form=form), 400

    try:
        get_collection().insert_one(form.copy())
    except (PyMongoError, RuntimeError) as exc:
        # Database error: show it on the same page, do not redirect.
        return render_template("form.html", error=f"Could not save data: {exc}", form=form), 500

    # Success: redirect to another page.
    return redirect(url_for("success"))


@app.route("/success")
def success():
    return render_template("success.html", message="Data submitted successfully")


# ---------------------------------------------------------------- To-Do backend
def get_todo_collection():
    """Collection that stores the To-Do items."""
    return get_collection().database["todo_items"]


@app.route("/submittodoitem", methods=["POST"])
def submit_todo_item():
    """Accept itemName and itemDescription via POST and store them in MongoDB."""
    payload = request.get_json(silent=True) or request.form
    item_name = (payload.get("itemName") or "").strip()
    item_description = (payload.get("itemDescription") or "").strip()

    if not item_name or not item_description:
        return jsonify({"error": "itemName and itemDescription are required"}), 400

    try:
        get_todo_collection().insert_one(
            {"itemName": item_name, "itemDescription": item_description}
        )
    except (PyMongoError, RuntimeError) as exc:
        return jsonify({"error": f"Could not save item: {exc}"}), 500

    return jsonify({"message": "To-Do item saved"}), 201
if __name__ == "__main__":
    app.run(debug=True)
