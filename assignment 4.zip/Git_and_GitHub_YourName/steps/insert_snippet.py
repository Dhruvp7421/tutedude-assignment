"""Helper used by git_workflow.sh: insert a code snippet into a file next to an anchor line.

usage: insert_snippet.py <file> <anchor text> <snippet file> <before|after>
"""
import sys

path, anchor, snippet_file, mode = sys.argv[1:5]
with open(path, encoding="utf-8") as f:
    lines = f.read().split("\n")
with open(snippet_file, encoding="utf-8") as f:
    snippet = f.read().rstrip("\n").split("\n")

for i, line in enumerate(lines):
    if anchor in line:
        pos = i if mode == "before" else i + 1
        lines[pos:pos] = snippet
        break
else:
    sys.exit(f"anchor not found: {anchor}")

with open(path, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))
