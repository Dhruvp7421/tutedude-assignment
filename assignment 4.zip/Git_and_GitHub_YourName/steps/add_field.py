"""Helper used by git_workflow.sh: add one labelled text input to the To-Do form.

usage: add_field.py <html file> <label> <input name>
The field is inserted just above the submit button.
"""
import sys

path, label, name = sys.argv[1:4]
block = [
    f'      <label for="{name}">{label}</label>',
    f'      <input type="text" id="{name}" name="{name}">',
    "",
]
with open(path, encoding="utf-8") as f:
    lines = f.read().split("\n")

for i, line in enumerate(lines):
    if "<button" in line:
        lines[i:i] = block
        break
else:
    sys.exit("submit button not found")

with open(path, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))
