#!/usr/bin/env bash
# Git & GitHub assignment - full workflow (Tasks 1-4) on the Flask project.
#
# Usage:
#   ./git_workflow.sh                                   # demo: uses a local "origin" repo
#   ./git_workflow.sh <github-username> <ssh-remote>    # real run, e.g.
#   ./git_workflow.sh Tutedude git@github.com:Tutedude/flask-git-assignment.git
#
# For a real run, first create an EMPTY-except-README repository on GitHub, add your SSH key
# to your GitHub account (Settings -> SSH and GPG keys) and check it with: ssh -T git@github.com
# Branch names are built from <github-username> (e.g. Tutedude and Tutedude_new).

set -uo pipefail
export GIT_PAGER=cat PAGER=cat GIT_EDITOR=true

GH_USER="${1:-yourusername}"
REMOTE="${2:-}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="${WORK_DIR:-$HERE/demo_run}"
GIT_NAME_VALUE="${GIT_NAME:-YourName}"
GIT_EMAIL_VALUE="${GIT_EMAIL:-you@example.com}"

run() {            # print the command, then execute it; stop if it fails
  echo; echo "\$ $1"
  eval "$1" || { echo "!! command failed"; exit 1; }
}
run_expect_fail() { # same, but a failure (e.g. merge conflict) is expected
  echo; echo "\$ $1"
  eval "$1" || echo "(command stopped with a conflict, as expected)"
}
note()   { echo; printf '%s\n' "$1" | sed 's/^/# /'; }
banner() { echo; echo "=============================================================="; echo "$*"; echo "=============================================================="; }

# ------------------------------------------------------------------ setup
rm -rf "$WORK"; mkdir -p "$WORK"
if [ -z "$REMOTE" ]; then
  # Demo only: stand-in for a freshly created GitHub repository that has a README.
  git init -q --bare -b main "$WORK/origin.git"
  REMOTE="$WORK/origin.git"
  git clone -q "$REMOTE" "$WORK/seed" 2>/dev/null
  ( cd "$WORK/seed" && git checkout -q -b main && echo "# flask-git-assignment" > README.md \
    && git add README.md && git -c user.name="$GIT_NAME_VALUE" -c user.email="$GIT_EMAIL_VALUE" \
       commit -q -m "Initial commit" && git push -q origin main ) 2>/dev/null
  rm -rf "$WORK/seed"
fi

# ------------------------------------------------------------------ TASK 1
banner "TASK 1: Repository setup and first branch"
cd "$WORK"
run "git clone $REMOTE flask-git-assignment"
cd flask-git-assignment
git config user.name "$GIT_NAME_VALUE"; git config user.email "$GIT_EMAIL_VALUE"
if [ -n "${COMMIT_TRAILER:-}" ]; then   # optional trailer appended to every commit message
  printf '%s\n' "$COMMIT_TRAILER" > .git/trailer.txt
  cat > .git/hooks/commit-msg <<'HOOK'
#!/bin/sh
f="$1"
[ -n "$(tail -c1 "$f")" ] && printf '\n' >> "$f"      # make sure the file ends with a newline
[ -n "$(tail -n1 "$f")" ] && printf '\n' >> "$f"      # blank line before the trailer block
cat "$(dirname "$0")/../trailer.txt" >> "$f"
HOOK
  chmod +x .git/hooks/commit-msg
fi
run "git branch"
run "git checkout -b $GH_USER"
note "Copy the Flask project files into the repository"
cp -r "$HERE/base_project/." .
run "git status --short"
run "git add ."
run "git commit -m \"Add Flask project files\""
run "git push -u origin $GH_USER"
run "git checkout main"
run "git merge --no-ff $GH_USER -m \"Merge branch '$GH_USER' into main\""
run "git push origin main"
run "git log --oneline --graph --all --decorate"

# ------------------------------------------------------------------ TASK 2
banner "TASK 2: Update JSON and resolve conflicts"
run "git checkout -b ${GH_USER}_new"
note "Update the content of data.json (the file served by the /api route)"
cp "$HERE/steps/data_new_update.json" data.json
run "git diff"
run "git add data.json"
run "git commit -m \"Update data.json content for /api route\""
run "git push -u origin ${GH_USER}_new"

note "Meanwhile data.json is also changed on main, so the merge below produces a conflict"
run "git checkout main"
cp "$HERE/steps/data_main_update.json" data.json
run "git add data.json"
run "git commit -m \"Update data.json on main\""

run_expect_fail "git merge ${GH_USER}_new"
run "git status --short"
run "cat data.json"
note "Resolve by accepting the changes from the ${GH_USER}_new branch (during a merge, 'theirs' is the branch being merged in)"
run "git checkout --theirs data.json"
run "cat data.json"
run "git add data.json"
run "git commit -m \"Resolve conflict in data.json: accept changes from ${GH_USER}_new\""
run "git push origin main"
run "git log --oneline --graph --all --decorate"

# ------------------------------------------------------------------ TASK 3
banner "TASK 3: Parallel feature development"
run "git branch master_1 main"
run "git branch master_2 main"
run "git branch"

note "master_1: To-Do page in the frontend (Item Name, Item Description)"
run "git checkout master_1"
cp "$HERE/steps/todo.html" templates/todo.html
python3 "$HERE/steps/insert_snippet.py" app.py 'return render_template("form.html", error=None, form={})' "$HERE/steps/todo_page_route.txt" after
run "git status --short"
run "git add templates/todo.html app.py"
run "git commit -m \"Add To-Do page with Item Name and Item Description form\""
run "git push -u origin master_1"

note "master_2: backend route /submittodoitem that stores the item in MongoDB"
run "git checkout master_2"
python3 "$HERE/steps/insert_snippet.py" app.py 'if __name__ == "__main__":' "$HERE/steps/submittodoitem_route.txt" before
run "git diff --stat"
run "git add app.py"
run "git commit -m \"Add /submittodoitem route to store To-Do items in MongoDB\""
run "git push -u origin master_2"

note "Merge both feature branches into main"
run "git checkout main"
run "git merge --no-ff master_1 -m \"Merge branch 'master_1' into main\""
run "git merge --no-ff master_2 -m \"Merge branch 'master_2' into main\""
run "git push origin main"
run "git log --oneline --graph --all --decorate"

# ------------------------------------------------------------------ TASK 4
banner "TASK 4: Sequential commits, reset and rebase"
run "git checkout master_1"

note "Commit 1: Item ID"
python3 "$HERE/steps/add_field.py" templates/todo.html "Item ID" itemId
run "git add templates/todo.html"
run "git commit -m \"Add Item ID field to To-Do form\""
note "Commit 2: Item UUID"
python3 "$HERE/steps/add_field.py" templates/todo.html "Item UUID" itemUuid
run "git add templates/todo.html"
run "git commit -m \"Add Item UUID field to To-Do form\""
note "Commit 3: Item Hash"
python3 "$HERE/steps/add_field.py" templates/todo.html "Item Hash" itemHash
run "git add templates/todo.html"
run "git commit -m \"Add Item Hash field to To-Do form\""
run "git push origin master_1"
run "git log --oneline -4"

note "Merge master_1 into main"
run "git checkout main"
run "git merge --no-ff master_1 -m \"Merge branch 'master_1' into main\""
run "git push origin main"
run "git log --oneline --graph --decorate -8"

note "Git reset: roll main back (soft) to the commit where only Item ID was added"
ID_COMMIT="$(git log --format=%h --grep='Add Item ID field' -n 1 main)"
run "git reset --soft $ID_COMMIT"
run "git status --short"
run "git log --oneline --graph --decorate -3"
note "Re-commit the staged state on main"
run "git commit -m \"Re-commit staged changes after soft reset\""
run "git log --oneline --graph --all --decorate"

note "Rebase: replay master_1's commits on top of main, keeping each commit (no squash).
main already contains the UUID and Hash fields (re-committed after the soft reset), so replaying those
commits overlaps with main. '-X ours' resolves such overlaps in favour of main (the branch we rebase onto),
and '--empty=keep' stops git from dropping the commits that become empty, so every commit is preserved."
run "git rebase -X ours --empty=keep main master_1"
run "git log --oneline --graph --all --decorate"

note "main and master_1 history was rewritten, so the push needs --force-with-lease"
run "git push --force-with-lease origin main master_1"
run "git branch -vv"
