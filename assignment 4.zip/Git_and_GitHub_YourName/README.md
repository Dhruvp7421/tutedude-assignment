# Git & GitHub - DevOps Assignment

Full Git workflow (SSH, branching, merging, conflict resolution, sequential commits, `git reset --soft`, rebase) on a Flask + MongoDB project.

| Item | Purpose |
|---|---|
| `Git_and_GitHub_Documentation.docx` | Documentation with commands, output and explanations |
| `git_workflow.sh` | Runs every command of Tasks 1-4 |
| `execution_log.txt` | Complete output of one run of the script |
| `base_project/` | Flask project used as the starting files |
| `steps/` | Small files the script uses for each change |
| `final_project/` | Flask project as it is on `main` at the end |

## Run it against your own GitHub repository

1. Create a GitHub repository (tick "Add a README") and add your SSH key to your GitHub account.
2. Run:

```bash
./git_workflow.sh <your-github-username> git@github.com:<your-github-username>/<repository>.git
```

Without arguments the script runs a demo against a local repository instead.

GitHub repository: <paste your link here>
